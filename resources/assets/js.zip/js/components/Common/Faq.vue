<template>
	<div>
		<div class="inner_banner faq_banner">
			<div class="container">
				<div class="faq_form_wrapper">
					<h2>Frequently Asked Questions</h2>
				</div>
			</div>
		</div>
		<!-- About Content -->
		<section class="about_content_wrapper">
			<div class="container">
				<h2 class="title_heading">FAQ</h2>
				<div class="faq_content_wrapper row clearfix">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<ul class="faq_navbar">
							<li>DO YOU THINK THERE IS AN AFTERLIFE FOR ANIMALS OTHER THAN HUMAN BEINGS?</li>
							<li>HOW MANY GOLF BALLS CAN FIT IN A SCHOOL BUS?</li>
							<li>HOW MUCH SHOULD YOU CHARGE TO WASH ALL THE WINDOWS IN SEATTLE?</li>
						</ul>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<ul class="faq_navbar">
							<li>DO YOU THINK THERE IS AN AFTERLIFE FOR ANIMALS OTHER THAN HUMAN BEINGS?</li>
							<li>WHY ARE MANHOLE COVERS ROUND?
								<p>The wide ranging nature of items and practices to which the term creative can be sensibly applied also makes a straightforward definition difficult</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>
	</div>
</template>


<script>
export default {

}
</script>