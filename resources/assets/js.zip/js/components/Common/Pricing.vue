<template>
	
	<div>
	<!-- <div class="inner_banner pricing_banner">
			<div class="container">
				<div class="banner_content">
					<h2>Simple  Quick  Secure<br> The best service for your files</h2>
					<a href="#" class="btn banner_btn">TRY IT FREE</a>
				</div>
			</div>
		</div> -->

		<!-- Contact Content -->
		<section class="pricing_plans_wrapper">
			<div class="container clearfix">
				<div class="plan_S_wrapper">
					<h2>Choose the best plan for your needs</h2>
					<p>Brings you the business-class features with PRO account</p>
				</div>
				<div class="plan__box_wrappernew row clearfix">
					<div class="col-lg-3 col-md-3 col-sm-6 col-12">
						<div class="plan_price_main_box">
							<h3>Free</h3>
							<img src="img/plan_icon_1.png" class="plan_icon">
							<div class="plan_time">
								<h1>0</h1><span>/month</span>
							</div>
							<p>Lorem ipsum dolor sit amet. sed do eiusmod tempor incididunt ut. Labore et dolore magna aliqua.</p>
							<a href="#" class="btn green_btn">try it now</a>
							<div class="dis_n small_text">for 14 days</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 col-12">
						<div class="plan_price_main_box special_price_box">
							<div class="ribbon"><span id="changeText">Your Plan</span></div>
							<h3>Pro</h3>
							<img src="/assets/img/plan_icon_2.png" class="plan_icon">
							<div class="plan_time">
								<h1>14</h1><span>/month</span>
							</div>
							<p>Lorem ipsum dolor sit amet. sed do eiusmod tempor incididunt ut. Labore et dolore magna aliqua.</p>
							<a href="#" class="btn green_btn">Current plan</a>
							<div class="small_text">for 14 days</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 col-12">
						<div class="plan_price_main_box">
							<h3>Business</h3>
							<img src="/assets/img/plan_icon_3.png" class="plan_icon">
							<div class="plan_time">
								<h1>49</h1><span>/month</span>
							</div>
							<p>Lorem ipsum dolor sit amet. sed do eiusmod tempor incididunt ut. Labore et dolore magna aliqua.</p>
							<a href="#" class="btn green_btn">try it now</a>
							<div class="small_text">for 14 days</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-6 col-12">
						<div class="plan_price_main_box">
							<h3> Enterprise</h3>
							<img src="/assets/img/plan_icon_4.png" class="plan_icon">
							<div class="no_t plan_time">
								<h1>Call</h1><span></span>
							</div>
							<p>Lorem ipsum dolor sit amet. sed do eiusmod tempor incididunt ut. Labore et dolore magna aliqua.</p>
							<a href="#" class="btn green_btn">try it now</a>
							<div class="small_text">for 14 days</div>
						</div>
					</div>
				</div>
			</div>
		</section>
</div>
</template>