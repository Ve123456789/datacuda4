<template>
		<div>
			<div class="inner_banner faq_banner">
			<div class="container">
				<div class="faq_form_wrapper">
					<h2>Privacy/ Terms of Service</h2>
				</div>
			</div>
		</div>
		<!-- Contact Content -->
		<section class="Terms_of_Service_wrapper">
			<div class="container clearfix">
				<h2 class="contact_title_heading">Privacy/ Terms of Service</h2>
				<div class="Terms_of_Service_content">
					<p>Thank you for using Datacuda! These terms of service (hereinafter referred to as the " Terms ") establish the rules for the use of our services, software and websites (hereinafter referred to as " Services ") and access to them. If you do not reside in the US, Canada or Mexico (hereinafter referred to as " North America "), then this agreement is concluded between you and the Datacuda. If you live in North America, this agreement is between you and Datacuda, Inc. Our Privacy Policy describes how we collect and use your information, and in our Acceptable Use PolicyThe duties that you take on yourself, using our Services, are indicated. By using our Services, you agree to these Terms, our Privacy Policy and our Acceptable Use Policy . If you use the Services for you for an organization, you agree to these Terms on behalf of this organization.</p>
					<div class="highlight_terms">
						<h6>Your materials and permissions</h6>
						<p>When you use the Services, you provide us with your files, data, messages, contact information, etc. (hereinafter referred to as " Your Materials "). Your materials belong to you. These terms do not grant us any rights to your materials, other than the limited rights required to operate the Services and provide you with relevant services.</p>
						<p>We need your permission to post your materials, make backup copies for them and, at your request, give them access to others. Also, our Services provide you with certain functions: for example, create thumbnails of photos, preview documents, allow comments, sort files, provide the ability to edit, share, search among them. To perform these and other functions, our system may need to access your materials, store them and scan. You grant us permission to do this, and this permission also applies to our affiliates and reliable third parties with whom we operate.</p>
					</div>
					<div class="highlight_terms">
						<h6>Sharing your materials</h6>
						<p>With the help of our Services, you can give other people access to your materials, so please carefully consider whether you should provide access to certain files.</p>
						<p>We need your permission to post your materials, make backup copies for them and, at your request, give them access to others. Also, our Services provide you with certain functions: for example, create thumbnails of photos, preview documents, allow comments, sort files, provide the ability to edit, share, search among them. To perform these and other functions, our system may need to access your materials, store them and scan. You grant us permission to do this, and this permission also applies to our affiliates and reliable third parties with whom we operate.</p>
					</div>
				</div>
			</div>
		</section>
		<!-- Footer -->
</div>
</template>

<script>
export default {

}
</script>