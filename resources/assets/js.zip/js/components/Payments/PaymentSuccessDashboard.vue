<template>
    <section class="payments_wrapper white_bg">
        <div class="container">
            <div class="payments_main_box">
                <div class="row">
                    <div class="payment_left_content col-md-7">
                        <div class="payment_success">
                            <img src="/assets/img/rocket.svg">
                            <h2>Payment successful</h2>
                        </div>
                    </div>
                    <div class="payment_right_content white_bg col-md-5">
                        <div class="pay_dashbord_right_content">
                            <h3>You can track when your<br>files are viewed and payments received on<br>your dashboard</h3>
                            <a href="#" class="btn green_btn">return to dashboard</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
    <script>
        export default {
            data() {

            }
        }
    </script>