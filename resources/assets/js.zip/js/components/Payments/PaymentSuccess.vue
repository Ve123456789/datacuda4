<template>
    <section class="payments_wrapper white_bg">
        <div class="container">
                 <flash-message class="myCustomClass"></flash-message>

            <div class="payments_main_box">
                <div class="row">
                    <div class="payment_left_content col-md-7">
                        <div class="payment_success">
                            <img src="/assets/img/rocket.svg">
                            <h2>Payment successful</h2>
                        </div>
                    </div>
                    <div class="payment_right_content white_bg col-md-5">
                        <div class="pay_success_right_content">
                            <h3>You will receive a copy<br>of your paid invoice<br>by email</h3>
                            <img src="/assets/img/datacuda.png" class="pay_logo">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
<!--
<script>
    export default {
        data() {

        }
    }
</script>-->
