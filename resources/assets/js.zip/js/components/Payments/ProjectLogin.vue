<template>
<div>
    <section class="about_content_wrapper">
        <!-- <div class="container">        
         <img src="../../../img/close.svg" class="m_close_btn" @click="hide">

            <div class="col-md-4">
                <div class="form_content_box">
                    <div class="form_logo"><img src="../../../img/datacuda.png"></div>
                    <flash-message class="myCustomClass"></flash-message>

                    <h2>Login to view your Shared Project here:</h2>
                        <div class="form-group">
                            <input type="password" name = "password" class="form_cus form-control" id="pwd" placeholder="Password" v-model="password">
                        </div>                   
                </div>
            </div>
        </div> -->
    </section>
 </div>
</template>
<script>
    export default {
        data() {
            return {}
        }
    }
</script>