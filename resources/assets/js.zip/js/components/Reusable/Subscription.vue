<template>
    <div class="finance_wrapper" id="biling_data">
        <ul class="profile_nav">
            <li><a href="#" class="active">Subscription </a></li>
        </ul>
        <div class="payment_content_data">
            <div class="payment_data_heading clearfix">
                <h3>Business Plan</h3>
                <a href="#" class="view_plan_btn tdn blue_color">View Plans</a>
            </div>
            <table class="table table_responsive">
                <thead>
                <tr>
                    <th scope="col">Status</th>
                    <th scope="col">Active</th>
                    <th scope="col">Recurring $300.00</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th>Customer1</th>
                    <td>Project1</td>
                    <td>$300.00</td>
                </tr>
                <tr>
                    <th>Customer1</th>
                    <td>Project1</td>
                    <td>$300.00</td>
                </tr>
                <tr>
                    <th>Customer1</th>
                    <td>Project1</td>
                    <td>$300.00</td>
                </tr>
                </tbody>
            </table>
        </div>
        <div class="payment_content_data">
            <div class="payment_data_heading clearfix">
                <h3>Charges and Credits</h3>
                <a href="#" class="view_plan_btn tdn blue_color">View Plans</a>
            </div>
            <table class="table table_responsive">
                <thead>
                <tr>
                    <th scope="col">Subscription</th>
                    <th scope="col">Charged on</th>
                    <th scope="col">Invoice date</th>
                    <th scope="col">Amount</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>Business Plan</td>
                    <td>Nov 2, 2017 12:52 PM</td>
                    <td>Nov 1, 2017</td>
                    <td>$300.00</td>
                </tr>
                <tr>
                    <td>Add on</td>
                    <td>Nov 2, 2017 12:52 PM</td>
                    <td>Nov 1, 2017</td>
                    <td>$300.00</td>
                </tr>
                <tr>
                    <td>Add on</td>
                    <td>Nov 2, 2017 12:52 PM</td>
                    <td>Nov 1, 2017</td>
                    <td>$300.00</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>
<script>
    export default {

    }
</script>
