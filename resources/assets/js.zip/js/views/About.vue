<template>
    <div>About Page</div>
</template>

<script>
export default {

}
</script>