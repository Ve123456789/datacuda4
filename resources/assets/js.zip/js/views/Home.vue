<template>
    <div>Home Page</div>
</template>

<script>
export default {

}
</script>